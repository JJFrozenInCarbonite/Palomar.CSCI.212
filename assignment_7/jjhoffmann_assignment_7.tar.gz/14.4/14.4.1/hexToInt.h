#ifndef HEXTOINT_H
#define HEXTOINT_H

int hexToInt(char *stringPtr);

#endif // HEXTOINT_H