as -o checkPrimeNumber.o checkPrimeNumber.s
gcc -o main checkPrimeNumber.o
rm *.o