as -o checkPrimeNumber.o checkPrimeNumber.s
gcc -o main checkPrimeNumber.c checkPrimeNumber.o
rm *.o