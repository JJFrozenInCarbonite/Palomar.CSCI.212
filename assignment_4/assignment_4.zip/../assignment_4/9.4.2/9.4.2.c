/* f.c */
int f(void) {
return 0;
}