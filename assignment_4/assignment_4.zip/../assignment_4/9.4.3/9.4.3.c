/* g.c */
int g(void) {
return 123;
}